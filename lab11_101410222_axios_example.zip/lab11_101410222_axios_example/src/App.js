import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import PersonList from './PersonList';

function App() {
    return (
        <div className="App">
            <PersonList />
        </div>
    );
}

export default App;
