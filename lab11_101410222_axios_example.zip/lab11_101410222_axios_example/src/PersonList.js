import React, { Component } from 'react';
import axios from 'axios';

class PersonList extends Component {
    // Define state default values
    state = {
        persons: []
    }

    // Component Lifecycle Callback
    componentDidMount() {
        axios.get('https://randomuser.me/api/?results=10')
            .then(res => {
                console.log(res.data);
                const persons = res.data.results;
                this.setState({ persons });
            })
            .catch(error => {
                console.error('Error fetching data:', error);
            });
    }

    render() {
        return (
            <div>
                <h2>Person List</h2>
                <ul>
                    {this.state.persons.map((person, index) => (
                        <li key={index} className="person">
                            <img src={person.picture.medium} alt={`${person.name.first} ${person.name.last}`} />
                            <div>
                                <p><strong>Name:</strong> {person.name.first} {person.name.last}</p>
                                <p><strong>Gender:</strong> {person.gender}</p>
                                <p><strong>Phone:</strong> {person.phone}</p>
                                <p><strong>Email:</strong> {person.email}</p>
                                <p><strong>Location:</strong> {person.location.street.name}, {person.location.city}, {person.location.state}, {person.location.country}</p>
                                <p><strong>Birthdate:</strong> {new Date(person.dob.date).toLocaleDateString()}</p>
                                <p><strong>Registration Date:</strong> {new Date(person.registered.date).toLocaleDateString()}</p>
                            </div>
                        </li>
                    ))}
                </ul>
            </div>
        );
    }
}

export default PersonList;
